﻿Abrir o Arquivo ComunicaDefi.exe para iniciar o simulador
#########
Equipe ComunicaDefi